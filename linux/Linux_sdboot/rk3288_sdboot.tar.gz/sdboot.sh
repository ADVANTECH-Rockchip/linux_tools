#!/bin/bash -e

function createGPT
{
echo "Creating GPT..."
DEVICE=$1

parted -s $DEVICE mklabel gpt
parted -s $DEVICE mkpart uboot 8M 13M
parted -s $DEVICE mkpart trust 13M 17M
parted -s $DEVICE mkpart misc 17M 21M
parted -s $DEVICE mkpart boot 21M 53M
parted -s $DEVICE mkpart recovery 53M 85M
parted -s $DEVICE mkpart backup 85M 117M
parted -s $DEVICE mkpart oem 117M 181M
parted -s $DEVICE mkpart rootfs 181M 3765M
parted -s $DEVICE mkpart userdata 3765M 100%

partprobe
sgdisk --partition-guid=8:614e0000-0000-4b53-8000-1d28000054a9 $DEVICE
}

function downloadImages
{
echo "Downloading images..."
DEVICE=$1

./mkimage \
-n rk3288 \
-T rksd \
-d rkbin/bin/rk32/rk3288_ddr_400MHz_v1.06-uart-disable.bin \
rockdev/idbloader.img
cat rkbin/bin/rk32/rk3288_miniloader_v2.36.bin >> rockdev/idbloader.img

set -x

dd if=rockdev/idbloader.img of=$DEVICE seek=64
dd if=rockdev/image/parameter.txt of=$DEVICE seek=$((0x2000))
dd if=rockdev/image/uboot.img of=${DEVICE}1
dd if=rockdev/image/trust.img of=${DEVICE}2
dd if=rockdev/image/misc.img of=${DEVICE}3
dd if=rockdev/image/boot.img of=${DEVICE}4
dd if=rockdev/image/recovery.img of=${DEVICE}5

dd if=rockdev/image/oem.img of=${DEVICE}7
dd if=rockdev/image/rootfs.img of=${DEVICE}8
dd if=rockdev/image/userdata.img of=${DEVICE}9

set +x

sync && sync
}

createGPT $1

downloadImages $1

echo "Done!"
